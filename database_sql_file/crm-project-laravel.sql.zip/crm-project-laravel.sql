-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 02, 2023 at 07:08 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `crm-project-laravel`
--

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

CREATE TABLE `brands` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `brand_name` varchar(191) NOT NULL,
  `brand_description` text NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `brands`
--

INSERT INTO `brands` (`id`, `brand_name`, `brand_description`, `created_at`, `updated_at`) VALUES
(7, 'Uniliver', 'fdghhdhfdh', NULL, NULL),
(5, 'Nokia', 'gdfh gjk jhjk; klj\'\'\'\'\'jlgkg', NULL, NULL),
(6, 'Oppo', 'ghjhfgj gjghhjl', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `category_name` varchar(191) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `category_name`, `created_at`, `updated_at`) VALUES
(10, 'Electronics', '2023-10-05 03:55:37', '2023-10-05 03:55:37');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(191) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL,
  `receiver` int(11) NOT NULL,
  `message` text NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`id`, `user_id`, `receiver`, `message`, `created_at`, `updated_at`) VALUES
(1, 11, 2, 'hi admin vaia', '2023-10-13 17:15:25', '2023-10-13 17:15:25'),
(2, 2, 11, 'hmm ', '2023-10-13 17:16:09', '2023-10-13 17:16:09'),
(3, 6, 2, 'i am jannat akter', '2023-10-13 17:26:38', '2023-10-13 17:26:38'),
(4, 2, 6, 'yes, i know you sister.', '2023-10-13 17:27:23', '2023-10-13 17:27:23'),
(5, 2, 6, 'how are you', '2023-10-13 17:27:34', '2023-10-13 17:27:34'),
(6, 6, 2, 'i am fine.', '2023-10-13 17:28:27', '2023-10-13 17:28:27'),
(7, 2, 6, 'how can i help u?', '2023-10-13 17:28:55', '2023-10-13 17:28:55'),
(8, 6, 2, 'can u teach me laravel', '2023-10-13 17:31:28', '2023-10-13 17:31:28'),
(9, 9, 2, 'hi am salam', '2023-10-13 17:36:20', '2023-10-13 17:36:20'),
(10, 2, 9, 'yes', '2023-10-13 17:36:28', '2023-10-13 17:36:28'),
(11, 9, 2, 'i want to introduce with you', '2023-10-13 17:36:50', '2023-10-13 17:36:50'),
(12, 9, 2, 'are you agree?', '2023-10-13 17:47:21', '2023-10-13 17:47:21'),
(13, 2, 9, 'yes, i am agree.', '2023-10-13 17:54:58', '2023-10-13 17:54:58'),
(14, 5, 2, 'hi ', '2023-10-15 21:22:12', '2023-10-15 21:22:12'),
(15, 2, 5, 'yes', '2023-10-15 21:22:22', '2023-10-15 21:22:22'),
(16, 2, 5, 'brother', '2023-10-26 03:34:37', '2023-10-26 03:34:37'),
(17, 5, 2, 'hmm', '2023-10-26 03:34:48', '2023-10-26 03:34:48'),
(18, 2, 5, 'how can i help u?', '2023-10-26 03:35:05', '2023-10-26 03:35:05'),
(19, 5, 2, 'i need a help from you.', '2023-10-26 03:35:28', '2023-10-26 03:35:28'),
(20, 5, 2, 'hi hello', '2023-10-26 08:12:47', '2023-10-26 08:12:47'),
(21, 2, 5, 'hi i am employee', '2023-10-26 08:14:25', '2023-10-26 08:14:25');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_reset_tokens_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(5, '2014_10_12_100000_create_password_resets_table', 2),
(6, '2023_10_03_063939_create_categories_table', 2),
(7, '2023_10_04_053607_create_brands_table', 3),
(8, '2023_10_05_035715_create_products_table', 4),
(9, '2023_10_05_040515_create_product_multiple_images_table', 5),
(10, '2023_10_12_040702_create_messages_table', 6),
(11, '2023_10_16_034025_create_shopping_carts_table', 7),
(12, '2023_10_18_101154_create_orders_table', 8),
(13, '2023_10_18_101215_create_order_details_table', 8),
(14, '2023_10_19_091624_create_storehouses_table', 9),
(15, '2023_10_19_121129_create_states_table', 10);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL,
  `customer_name` varchar(191) NOT NULL,
  `c_shipping_address` varchar(191) NOT NULL,
  `c_country` varchar(255) NOT NULL,
  `c_state` int(191) DEFAULT NULL,
  `c_city` varchar(191) NOT NULL,
  `c_zipcode` varchar(191) NOT NULL,
  `c_email` varchar(191) NOT NULL,
  `c_phone` varchar(191) NOT NULL,
  `order_total` varchar(191) NOT NULL,
  `payment_type` varchar(191) NOT NULL,
  `status` varchar(191) NOT NULL DEFAULT '0',
  `date` varchar(191) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `customer_name`, `c_shipping_address`, `c_country`, `c_state`, `c_city`, `c_zipcode`, `c_email`, `c_phone`, `order_total`, `payment_type`, `status`, `date`, `created_at`, `updated_at`) VALUES
(1, 1, 'user', 'Khulna, sona danga.', 'Bangladesh', 4, 'Natore', 'dgdhdfh', 'mrkkarim1991@gmail.com', '01719475187', '135001', 'cash_on_delivery', '1', 'October 20,2023', NULL, '2023-10-19 22:40:24'),
(2, 1, 'user', 'Khulna, sona danga.', 'Bangladesh', 4, 'Natore', 'dgdhdfh', 'rezaulmimi1991@gmail.com', '225566', '112001', 'cash_on_delivery', '0', 'October 26,2023', NULL, NULL),
(3, 1, 'user', 'dgsdsh', 'dhdhdf', 6, 'fdffj', 'dfgsdgh', 'biss@gmail.com', '022222', '135001', 'cash_on_delivery', '0', 'October 26,2023', NULL, NULL),
(4, 1, 'user', 'khulna', 'Bangladesh', 5, 'Khulna.', 'khu123', 'jibnon@gmail.com', '22222', '735001', 'cash_on_delivery', '0', 'October 26,2023', NULL, NULL),
(5, 1, 'user', 'xdbdfxnfx', 'ncvncvn', 6, 'fjfgj', 'fncgnc', 'fff@gmail.com', '225566', '390001', 'cash_on_delivery', '0', 'October 26,2023', NULL, NULL),
(6, 1, 'user', 'fjndjfgj', 'fgjgfkgkgk', 5, 'ghkghghhkghk', 'gkhghk', 'fgjf@gmail.com', '225566', '56001', 'cash_on_delivery', '0', 'October 27,2023', NULL, NULL),
(7, 4, 'user2', 'Khulna, sona danga.', 'Bangladesh', 5, 'Khulna.', 'gjfj', 'kkk@gmail.com', '225566', '176001', 'cash_on_delivery', '0', 'October 27,2023', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `order_details`
--

CREATE TABLE `order_details` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_quantity` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  `color` int(11) DEFAULT NULL,
  `date` varchar(100) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `order_details`
--

INSERT INTO `order_details` (`id`, `order_id`, `product_id`, `product_quantity`, `price`, `color`, `date`, `created_at`, `updated_at`) VALUES
(1, 1, 9, 1, 15000, NULL, 'October 20,2023', NULL, NULL),
(2, 1, 8, 1, 120000, NULL, 'October 20,2023', NULL, NULL),
(3, 2, 7, 2, 56000, NULL, 'October 26,2023', NULL, NULL),
(4, 3, 9, 1, 15000, NULL, 'October 26,2023', NULL, NULL),
(5, 3, 8, 1, 120000, NULL, 'October 26,2023', NULL, NULL),
(6, 4, 9, 1, 15000, NULL, 'October 26,2023', NULL, NULL),
(7, 4, 8, 6, 120000, NULL, 'October 26,2023', NULL, NULL),
(8, 5, 8, 3, 120000, NULL, 'October 26,2023', NULL, NULL),
(9, 5, 9, 2, 15000, NULL, 'October 26,2023', NULL, NULL),
(10, 6, 7, 1, 56000, NULL, 'October 27,2023', NULL, NULL),
(11, 7, 8, 1, 120000, NULL, 'October 27,2023', NULL, NULL),
(12, 7, 7, 1, 56000, NULL, 'October 27,2023', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) NOT NULL,
  `token` varchar(191) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `password_reset_tokens`
--

CREATE TABLE `password_reset_tokens` (
  `email` varchar(191) NOT NULL,
  `token` varchar(191) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(191) NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `brand_id` int(11) NOT NULL,
  `storehouse_id` int(100) DEFAULT NULL,
  `product_name` varchar(191) NOT NULL,
  `product_thumbnail` text NOT NULL,
  `product_description` text NOT NULL,
  `price` varchar(191) NOT NULL,
  `featured` varchar(191) NOT NULL,
  `hot_deals` varchar(191) NOT NULL,
  `status` varchar(191) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `user_id`, `category_id`, `brand_id`, `storehouse_id`, `product_name`, `product_thumbnail`, `product_description`, `price`, `featured`, `hot_deals`, `status`, `created_at`, `updated_at`) VALUES
(7, 2, 10, 5, 1, 'Laptop-100', 'upload/product_images/110949724.blog2.jpg', '<p><strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>', '56000', '1', '1', '1', '2023-10-19 05:29:28', '2023-10-19 05:29:28'),
(8, 2, 10, 5, 1, 'Motor cycle', 'upload/product_images/970361817.moto1.jpeg', '<p><strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>', '120000', '1', '1', '1', '2023-10-19 05:30:23', '2023-10-19 05:30:23'),
(9, 2, 10, 7, 6, 'Flower', 'upload/product_images/585287354.rose4 - Copy.jpg', '<p><strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>', '15000', '1', '1', '1', '2023-10-19 05:31:31', '2023-10-19 05:31:31'),
(10, 2, 10, 7, 6, 'My product', 'upload/product_images/1761817297.pc3.jpg', '<p>This is one of the best product in Bangladesh.This is one of the best product in Bangladesh.This is one of the best product in Bangladesh.This is one of the best product in Bangladesh.This is one of the best product in Bangladesh.This is one of the best product in Bangladesh.This is one of the best product in Bangladesh.</p>', '52000', '1', '1', '0', '2023-10-27 00:18:14', '2023-10-27 00:18:50');

-- --------------------------------------------------------

--
-- Table structure for table `product_multiple_images`
--

CREATE TABLE `product_multiple_images` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_image` text NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `product_multiple_images`
--

INSERT INTO `product_multiple_images` (`id`, `product_id`, `product_image`, `created_at`, `updated_at`) VALUES
(28, 10, 'upload/product_images/181832342.pc.jpg', '2023-10-27 00:18:14', '2023-10-27 00:18:14'),
(27, 10, 'upload/product_images/811920304.blog4.jpg', '2023-10-27 00:18:14', '2023-10-27 00:18:14'),
(26, 9, 'upload/product_images/715177432.rose6.jpg', '2023-10-19 05:31:31', '2023-10-19 05:31:31'),
(25, 9, 'upload/product_images/22045753.rose3.jpg', '2023-10-19 05:31:31', '2023-10-19 05:31:31'),
(24, 9, 'upload/product_images/757013999.rose3 - Copy.jpg', '2023-10-19 05:31:31', '2023-10-19 05:31:31'),
(19, 7, 'upload/product_images/1140835294.blog2.jpg', '2023-10-19 05:29:28', '2023-10-19 05:29:28'),
(20, 7, 'upload/product_images/854463177.blog4.jpg', '2023-10-19 05:29:28', '2023-10-19 05:29:28'),
(21, 7, 'upload/product_images/1420383943.pc.jpg', '2023-10-19 05:29:28', '2023-10-19 05:29:28'),
(22, 8, 'upload/product_images/883607586.car.jpeg', '2023-10-19 05:30:23', '2023-10-19 05:30:23'),
(23, 8, 'upload/product_images/693033990.moto1.jpeg', '2023-10-19 05:30:23', '2023-10-19 05:30:23'),
(29, 10, 'upload/product_images/516255742.pc2.jpg', '2023-10-27 00:18:14', '2023-10-27 00:18:14');

-- --------------------------------------------------------

--
-- Table structure for table `shopping_carts`
--

CREATE TABLE `shopping_carts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `states`
--

CREATE TABLE `states` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `state_name` varchar(191) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `states`
--

INSERT INTO `states` (`id`, `state_name`, `created_at`, `updated_at`) VALUES
(4, 'Rajshahi', NULL, NULL),
(5, 'Rangpur', NULL, NULL),
(6, 'Dhaka', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `storehouses`
--

CREATE TABLE `storehouses` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL,
  `address` varchar(191) NOT NULL,
  `phone` varchar(191) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `storehouses`
--

INSERT INTO `storehouses` (`id`, `name`, `address`, `phone`, `created_at`, `updated_at`) VALUES
(1, 'House-A', 'gdgdfhfgh fjfgjggk', '112233', NULL, NULL),
(6, 'House-B', 'sgdfhdfdfhf', '33226655', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL,
  `email` varchar(191) NOT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `image` text DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) NOT NULL,
  `role` int(11) NOT NULL DEFAULT 0,
  `nationality` varchar(100) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `designation` varchar(255) DEFAULT NULL,
  `salary` varchar(255) DEFAULT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `phone`, `image`, `email_verified_at`, `password`, `role`, `nationality`, `address`, `designation`, `salary`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'user', 'user@gmail.com', '01558825525', 'upload/user_images/1527510084.sarukh (2).jpg', NULL, '$2y$10$mOQrFDUzU5LRrIfqI0phEuhY.6lrqRKiOocAtpeuTv2rjsTgKvWOO', 0, NULL, NULL, NULL, NULL, NULL, '2023-10-02 22:24:18', '2023-10-27 04:08:38'),
(2, 'admin', 'admin@gmail.com', '111222', 'upload/user_images/945259355.jeet - Copy.jpg', NULL, '$2y$10$L1dAFrHXL8/A4ersNn29tOxHHIZ22AwSm3oUP2QSnmXAEUHbJBgJq', 1, NULL, NULL, NULL, NULL, NULL, '2023-10-02 22:24:18', '2023-10-03 23:00:26'),
(5, 'employee', 'employee@gmail.com', NULL, NULL, NULL, '$2y$10$LRjTzlLnnf3n82uVAObWWeVzyr5o.P3RqPOr19ewnCADxNxUtkVtS', 2, NULL, NULL, NULL, NULL, NULL, '2023-10-03 21:36:26', '2023-10-03 21:36:26'),
(4, 'user2', 'user2@gmail.com', NULL, NULL, NULL, '$2y$10$LRjTzlLnnf3n82uVAObWWeVzyr5o.P3RqPOr19ewnCADxNxUtkVtS', 0, NULL, NULL, NULL, NULL, NULL, '2023-10-03 21:36:26', '2023-10-03 21:36:26'),
(6, 'Jannat', 'jannat@gmail.com', NULL, NULL, NULL, '$2y$10$PxLr1B2Tb1wzn9RzmJl1EO9cpDKqDg9At/hJnxP4oLgOpC4Q4dzky', 2, NULL, NULL, NULL, NULL, NULL, '2023-10-04 21:29:50', '2023-10-04 21:29:50'),
(7, 'saddam', 'saddam@gmail.com', NULL, NULL, NULL, '$2y$10$YJPrhy/lYQl.AjheUaCrvOT.rUBuRqD.gfMprXKkL/pGaG0Pa.O5C', 0, NULL, NULL, NULL, NULL, NULL, '2023-10-04 21:34:20', '2023-10-04 21:34:20'),
(8, 'kalam', 'kalam@gmail.com', NULL, NULL, NULL, '$2y$10$e2LyffMgcML3LWjpLbceNuyIjVPwT8R1Ii00zcMoU3F1oyiNH7wzq', 0, NULL, NULL, NULL, NULL, NULL, '2023-10-05 21:42:03', '2023-10-05 21:42:03'),
(9, 'salam', 'salam@gmail.com', NULL, NULL, NULL, '$2y$10$XM0B4CwK6Mp1RF./xpOVlu2BgWdWVEyNNieYNKMvL.scMm8WmToxW', 2, NULL, NULL, NULL, NULL, NULL, '2023-10-05 21:44:14', '2023-10-05 21:44:14'),
(10, 'najmul', 'najmul@gmail.com', NULL, NULL, NULL, '$2y$10$itcwPnkb.0oxU745y5bj/u1kZMvjk8YvzbAlEThImL2Bp5T9285Ly', 0, NULL, NULL, NULL, NULL, NULL, '2023-10-05 21:45:00', '2023-10-05 21:45:00'),
(11, 'faruk', 'faruk@gmail.com', NULL, NULL, NULL, '$2y$10$y521GQZHQPWPWtgTLSSsMuXay9VtHHgFDkCxkrmlJKzmyoY8gmp2K', 2, NULL, NULL, NULL, NULL, NULL, '2023-10-13 14:26:30', '2023-10-13 14:26:30'),
(12, 'nayem', 'nayem@gmail.com', NULL, NULL, NULL, '$2y$10$g6lNIL/2yMgARPTp.n.rIuOKsgLDJ7L3uHaACE4f0Pwb.PyMMgl8i', 0, NULL, NULL, NULL, NULL, NULL, '2023-10-26 05:23:26', '2023-10-26 05:23:26'),
(13, 'sabbir', 'sabbir@gmail.com', NULL, NULL, NULL, '$2y$10$1WHtd/VRWAsDHFlBJe0bKeJqA/GAZyINYz1IchzuNlFRcxdbJjB9y', 2, NULL, NULL, NULL, NULL, NULL, '2023-10-26 05:24:18', '2023-10-26 05:24:18');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `brands`
--
ALTER TABLE `brands`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_details`
--
ALTER TABLE `order_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_multiple_images`
--
ALTER TABLE `product_multiple_images`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `shopping_carts`
--
ALTER TABLE `shopping_carts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `states`
--
ALTER TABLE `states`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `storehouses`
--
ALTER TABLE `storehouses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `brands`
--
ALTER TABLE `brands`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `order_details`
--
ALTER TABLE `order_details`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `product_multiple_images`
--
ALTER TABLE `product_multiple_images`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `shopping_carts`
--
ALTER TABLE `shopping_carts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;

--
-- AUTO_INCREMENT for table `states`
--
ALTER TABLE `states`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `storehouses`
--
ALTER TABLE `storehouses`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
