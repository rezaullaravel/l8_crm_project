-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Oct 13, 2023 at 04:03 AM
-- Server version: 8.0.31
-- PHP Version: 8.0.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `crm-project-laravel`
--

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

DROP TABLE IF EXISTS `brands`;
CREATE TABLE IF NOT EXISTS `brands` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `brand_name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `brand_description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `brands`
--

INSERT INTO `brands` (`id`, `brand_name`, `brand_description`, `created_at`, `updated_at`) VALUES
(7, 'Uniliver', 'fdghhdhfdh', NULL, NULL),
(5, 'Nokia', 'gdfh gjk jhjk; klj\'\'\'\'\'jlgkg', NULL, NULL),
(6, 'Oppo', 'ghjhfgj gjghhjl', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
CREATE TABLE IF NOT EXISTS `categories` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `category_name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `category_name`, `created_at`, `updated_at`) VALUES
(10, 'Electronics', '2023-10-05 03:55:37', '2023-10-05 03:55:37');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
CREATE TABLE IF NOT EXISTS `failed_jobs` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `uuid` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

DROP TABLE IF EXISTS `messages`;
CREATE TABLE IF NOT EXISTS `messages` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `receiver` int NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`id`, `user_id`, `receiver`, `message`, `created_at`, `updated_at`) VALUES
(1, 5, 2, 'hi brother.', '2023-10-11 23:38:31', '2023-10-11 23:38:31'),
(2, 5, 2, 'I need a help', '2023-10-11 23:39:32', '2023-10-11 23:39:32'),
(3, 2, 5, 'how can i help you?', '2023-10-11 23:39:49', '2023-10-11 23:39:49'),
(4, 6, 2, 'hi admin vaia', '2023-10-11 23:56:00', '2023-10-11 23:56:00'),
(5, 2, 6, 'hi employee apu', '2023-10-11 23:56:44', '2023-10-11 23:56:44'),
(6, 6, 2, 'are you free now?', '2023-10-12 00:04:38', '2023-10-12 00:04:38'),
(7, 2, 6, 'no, i am bus now.', '2023-10-12 00:05:28', '2023-10-12 00:05:28'),
(8, 2, 6, 'now i am at office', '2023-10-12 00:06:40', '2023-10-12 00:06:40'),
(9, 6, 2, 'amar sonar bangla', '2023-10-12 00:22:07', '2023-10-12 00:22:07'),
(10, 6, 2, 'din din protidin', '2023-10-12 00:22:48', '2023-10-12 00:22:48'),
(11, 2, 6, 'jay jay din', '2023-10-12 00:22:59', '2023-10-12 00:22:59'),
(12, 6, 2, 'akashe te lokkho tara', '2023-10-12 00:24:21', '2023-10-12 00:24:21'),
(13, 2, 6, 'chad kintu ekta re', '2023-10-12 00:24:41', '2023-10-12 00:24:41'),
(14, 6, 2, 'I have taken my launch.', '2023-10-12 03:43:20', '2023-10-12 03:43:20'),
(15, 2, 6, 'I also.', '2023-10-12 03:43:31', '2023-10-12 03:43:31'),
(16, 6, 2, 'uttore voyonkor jongol', '2023-10-12 04:26:23', '2023-10-12 04:26:23'),
(17, 2, 6, 'dokkhine te megh hay', '2023-10-12 04:26:46', '2023-10-12 04:26:46'),
(18, 6, 2, 'hi hi hi', '2023-10-12 04:27:09', '2023-10-12 04:27:09'),
(19, 2, 6, 'bibi bi', '2023-10-12 04:27:18', '2023-10-12 04:27:18'),
(20, 6, 2, 'tomar amar aina valobasa', '2023-10-12 04:27:50', '2023-10-12 04:27:50'),
(21, 2, 6, 'sopno rongin ektu notun asa', '2023-10-12 04:28:16', '2023-10-12 04:28:16'),
(22, 6, 2, 'hello', '2023-10-12 05:05:05', '2023-10-12 05:05:05'),
(23, 2, 6, 'hi apu', '2023-10-12 05:05:23', '2023-10-12 05:05:23');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_reset_tokens_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(5, '2014_10_12_100000_create_password_resets_table', 2),
(6, '2023_10_03_063939_create_categories_table', 2),
(7, '2023_10_04_053607_create_brands_table', 3),
(8, '2023_10_05_035715_create_products_table', 4),
(9, '2023_10_05_040515_create_product_multiple_images_table', 5),
(10, '2023_10_12_040702_create_messages_table', 6);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
CREATE TABLE IF NOT EXISTS `password_reset_tokens` (
  `email` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
CREATE TABLE IF NOT EXISTS `personal_access_tokens` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint UNSIGNED NOT NULL,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
CREATE TABLE IF NOT EXISTS `products` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `category_id` int NOT NULL,
  `brand_id` int NOT NULL,
  `product_name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_thumbnail` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `featured` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `hot_deals` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `user_id`, `category_id`, `brand_id`, `product_name`, `product_thumbnail`, `product_description`, `price`, `featured`, `hot_deals`, `status`, `created_at`, `updated_at`) VALUES
(10, 2, 10, 5, 'Chair', 'upload/product_images/1357456357.plastic-chari23jpeg.jpeg', '<p>dghfdjhfgjfgjg</p>', '5000', '1', '1', '1', '2023-10-10 06:52:06', '2023-10-10 06:52:06');

-- --------------------------------------------------------

--
-- Table structure for table `product_multiple_images`
--

DROP TABLE IF EXISTS `product_multiple_images`;
CREATE TABLE IF NOT EXISTS `product_multiple_images` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `product_id` int NOT NULL,
  `product_image` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `product_multiple_images`
--

INSERT INTO `product_multiple_images` (`id`, `product_id`, `product_image`, `created_at`, `updated_at`) VALUES
(29, 10, 'upload/product_images/532764271.plastic-chair5.jpeg', '2023-10-10 06:52:06', '2023-10-10 06:52:06'),
(31, 10, 'upload/product_images/1422064029.plastic-chari23jpeg.jpeg', '2023-10-10 06:52:06', '2023-10-10 06:52:06'),
(30, 10, 'upload/product_images/447688865.plastic-chari2.jpeg', '2023-10-10 06:52:06', '2023-10-10 06:52:06');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` int NOT NULL DEFAULT '0',
  `nationality` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `designation` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `salary` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `phone`, `image`, `email_verified_at`, `password`, `role`, `nationality`, `address`, `designation`, `salary`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'user', 'user@gmail.com', NULL, NULL, NULL, '$2y$10$mOQrFDUzU5LRrIfqI0phEuhY.6lrqRKiOocAtpeuTv2rjsTgKvWOO', 0, NULL, NULL, NULL, NULL, NULL, '2023-10-02 22:24:18', '2023-10-02 22:24:18'),
(2, 'admin', 'admin@gmail.com', '111222', 'upload/user_images/945259355.jeet - Copy.jpg', NULL, '$2y$10$L1dAFrHXL8/A4ersNn29tOxHHIZ22AwSm3oUP2QSnmXAEUHbJBgJq', 1, NULL, NULL, NULL, NULL, NULL, '2023-10-02 22:24:18', '2023-10-03 23:00:26'),
(5, 'employee', 'employee@gmail.com', NULL, NULL, NULL, '$2y$10$LRjTzlLnnf3n82uVAObWWeVzyr5o.P3RqPOr19ewnCADxNxUtkVtS', 2, NULL, NULL, NULL, NULL, NULL, '2023-10-03 21:36:26', '2023-10-03 21:36:26'),
(4, 'user2', 'user2@gmail.com', NULL, NULL, NULL, '$2y$10$LRjTzlLnnf3n82uVAObWWeVzyr5o.P3RqPOr19ewnCADxNxUtkVtS', 0, NULL, NULL, NULL, NULL, NULL, '2023-10-03 21:36:26', '2023-10-03 21:36:26'),
(6, 'Jannat', 'jannat@gmail.com', NULL, NULL, NULL, '$2y$10$PxLr1B2Tb1wzn9RzmJl1EO9cpDKqDg9At/hJnxP4oLgOpC4Q4dzky', 2, NULL, NULL, NULL, NULL, NULL, '2023-10-04 21:29:50', '2023-10-04 21:29:50'),
(7, 'saddam', 'saddam@gmail.com', NULL, NULL, NULL, '$2y$10$YJPrhy/lYQl.AjheUaCrvOT.rUBuRqD.gfMprXKkL/pGaG0Pa.O5C', 0, NULL, NULL, NULL, NULL, NULL, '2023-10-04 21:34:20', '2023-10-04 21:34:20'),
(8, 'kalam', 'kalam@gmail.com', NULL, NULL, NULL, '$2y$10$e2LyffMgcML3LWjpLbceNuyIjVPwT8R1Ii00zcMoU3F1oyiNH7wzq', 0, NULL, NULL, NULL, NULL, NULL, '2023-10-05 21:42:03', '2023-10-05 21:42:03'),
(9, 'salam', 'salam@gmail.com', NULL, NULL, NULL, '$2y$10$XM0B4CwK6Mp1RF./xpOVlu2BgWdWVEyNNieYNKMvL.scMm8WmToxW', 2, NULL, NULL, NULL, NULL, NULL, '2023-10-05 21:44:14', '2023-10-05 21:44:14'),
(10, 'najmul', 'najmul@gmail.com', NULL, NULL, NULL, '$2y$10$itcwPnkb.0oxU745y5bj/u1kZMvjk8YvzbAlEThImL2Bp5T9285Ly', 0, NULL, NULL, NULL, NULL, NULL, '2023-10-05 21:45:00', '2023-10-05 21:45:00');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
